CREATE TABLE IF NOT EXISTS `user` (
  `facebookID` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `photo` longtext,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `post` (
  `title` varchar(255) DEFAULT NULL,
  `alternativeTitle` varchar(255) DEFAULT NULL,
  `content` longtext,
  `genre` longtext,
  `author` varchar(255) DEFAULT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `slug` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `rating` varchar(255) DEFAULT NULL,
  `votes` int(11) DEFAULT NULL,
  `airStatus` varchar(255) DEFAULT NULL,
  `airDate` varchar(255) DEFAULT NULL,
  `totalEpisode` varchar(255) DEFAULT NULL,
  `lastEpisode` varchar(255) DEFAULT NULL,
  `episode` varchar(255) DEFAULT NULL,
  `anime` varchar(255) DEFAULT NULL,
  `startEpisode` varchar(255) DEFAULT NULL,
  `endEpisode` varchar(255) DEFAULT NULL,
  `myanimelist` varchar(255) DEFAULT NULL,
  `poster` varchar(255) DEFAULT NULL,
  `broadcast` varchar(255) DEFAULT NULL,
  `duration` varchar(255) DEFAULT NULL,
  `ageRating` varchar(255) DEFAULT NULL,
  `linkDownload` longtext,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45174 DEFAULT CHARSET=utf8;



